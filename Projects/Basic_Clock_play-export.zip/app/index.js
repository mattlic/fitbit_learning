import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";

// Update the clock every minute
clock.granularity = "minutes";

// Get a handle on the <text> element
const myLabel = document.getElementById("myLabel");
const backimage = document.getElementById("bkimage")

backimage.layer = 1;
myLabel.layer = 2;

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  
   // for testing
   backimage.href = util.minTest(today.getMinutes()); 
  
  // update backgroung
  // backimage.href = util.pickImage( hours );
  
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());

 
    
  myLabel.text = `${hours}:${mins}`;
}
